import { NgModule } from '@angular/core';
import { IonicPageModule } from 'ionic-angular';
import { ViewdOffersPage } from './viewd-offers';

@NgModule({
  declarations: [
    ViewdOffersPage,
  ],
  imports: [
    IonicPageModule.forChild(ViewdOffersPage),
  ],
})
export class ViewdOffersPageModule {}
